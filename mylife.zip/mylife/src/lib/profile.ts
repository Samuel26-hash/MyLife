export interface Profile {
  first_name: string | null;
  last_name: string | null;
  birthday: string | null;
  nationality: string | null;
  city: string | null;
  occupation: string | null;
  interests: string | null;
  hobbies: string | null;
  favorite_sport: string | null;
  strengths: string | null;
  improve_areas: string | null;
  goals_text: string | null;
  onboarding_done: number;
}

export type ProfileField = Exclude<keyof Profile, "onboarding_done">;

export interface FieldDef {
  key: ProfileField;
  label: string;
  type?: "text" | "date" | "textarea";
  placeholder?: string;
}

export const PROFILE_GROUPS: { title: string; fields: FieldDef[] }[] = [
  {
    title: "Über dich",
    fields: [
      { key: "first_name", label: "Vorname" },
      { key: "last_name", label: "Nachname" },
      { key: "birthday", label: "Geburtstag", type: "date" },
      { key: "nationality", label: "Nationalität", placeholder: "z. B. Schweiz" },
      { key: "city", label: "Wohnort", placeholder: "z. B. Riehen" },
      { key: "occupation", label: "Schule / Ausbildung / Beruf", placeholder: "z. B. Wirtschaftsmittelschule Basel" },
    ],
  },
  {
    title: "Interessen",
    fields: [
      { key: "hobbies", label: "Hobbys", type: "textarea", placeholder: "z. B. Fussball, Gitarre, Fitness" },
      { key: "favorite_sport", label: "Lieblingssport" },
      { key: "interests", label: "Interessen", type: "textarea" },
    ],
  },
  {
    title: "Ziele",
    fields: [
      { key: "strengths", label: "Meine Stärken", type: "textarea" },
      { key: "improve_areas", label: "Was ich verbessern möchte", type: "textarea" },
      { key: "goals_text", label: "Meine Ziele", type: "textarea" },
    ],
  },
];

export function ageFrom(birthday: string | null): number | null {
  if (!birthday) return null;
  const b = new Date(birthday);
  const now = new Date();
  let age = now.getFullYear() - b.getFullYear();
  if (now.getMonth() < b.getMonth() || (now.getMonth() === b.getMonth() && now.getDate() < b.getDate())) age--;
  return Number.isFinite(age) ? age : null;
}
