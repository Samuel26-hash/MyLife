// Alle Bereiche der App an einem Ort – Navigation, Landingpage und Platzhalter nutzen diese Liste.
import {
  BookOpen, CalendarDays, CloudSun, Dumbbell, Flag, LayoutDashboard, LineChart,
  Palette, Settings, Smartphone, Sparkles, User, UtensilsCrossed, Wallet,
  type LucideIcon,
} from "lucide-react";

export interface AppModule {
  path: string;
  label: string;
  icon: LucideIcon;
  /** Kurzbeschreibung aus Sicht der Benutzer */
  summary: string;
  /** Was im Modul geplant ist (für die Platzhalterseite) */
  planned?: string[];
  showOnLanding?: boolean;
}

export const MODULES: AppModule[] = [
  { path: "/app", label: "Dashboard", icon: LayoutDashboard, summary: "Dein Tag und dein Fortschritt auf einen Blick." },
  { path: "/app/profil", label: "Mein Profil", icon: User, summary: "Dein persönlicher Steckbrief.", showOnLanding: true },
  {
    path: "/app/schule", label: "Schule", icon: BookOpen, showOnLanding: true,
    summary: "Fächer und Noten im Schweizer System von 1 bis 6.",
    planned: ["Fächer anlegen und Noten mit Gewichtung eintragen", "Durchschnitt pro Fach und gesamt", "Entwicklung als Diagramm", "Stärkste Fächer und Fächer mit Verbesserungspotenzial"],
  },
  {
    path: "/app/ziele", label: "Ziele", icon: Flag, showOnLanding: true,
    summary: "Ziele setzen, Fortschritt verfolgen, Erfolge feiern.",
    planned: ["Ziele mit Kategorie, Zieldatum und Fortschritt", "Status: aktiv, erreicht, pausiert", "Ziele erscheinen auf dem Dashboard"],
  },
  {
    path: "/app/kalender", label: "Kalender", icon: CalendarDays, showOnLanding: true,
    summary: "Termine für Schule, Arbeit, Sport und Freizeit.",
    planned: ["Termine erstellen, bearbeiten und löschen", "Kategorien und Erinnerungen", "Nächste Termine auf dem Dashboard"],
  },
  {
    path: "/app/sport", label: "Sport", icon: Dumbbell, showOnLanding: true,
    summary: "Trainings, Bestleistungen und ein eigenes Fussball-Modul.",
    planned: ["Trainings mit Dauer, Übungen, Gewicht und Distanz", "Fussballspiele mit Toren, Assists, Dribblings und Zweikämpfen", "Entwicklung über Wochen und Monate", "Trainingsvorschläge zu deinen Zielen"],
  },
  {
    path: "/app/ernaehrung", label: "Ernährung", icon: UtensilsCrossed, showOnLanding: true,
    summary: "Mahlzeiten, Nährwerte und Wasser pro Tag.",
    planned: ["Frühstück, Mittag, Abend, Snacks und Getränke", "Kalorien, Protein, Kohlenhydrate, Fett, Ballaststoffe, Zucker", "Tages- und Wochenübersicht", "Allgemeine Infos, keine medizinische Beratung"],
  },
  {
    path: "/app/finanzen", label: "Finanzen", icon: Wallet, showOnLanding: true,
    summary: "Einnahmen, Ausgaben und Sparziele in CHF.",
    planned: ["Einnahmen und Ausgaben nach Kategorie", "Sparquote und monatliche Entwicklung", "Sparziele mit Fortschritt"],
  },
  {
    path: "/app/gewohnheiten", label: "Gewohnheiten", icon: Sparkles, showOnLanding: true,
    summary: "Routinen abhaken und Streaks aufbauen.",
    planned: ["Eigene Gewohnheiten wählen", "Tages- und Wochenfortschritt", "Streaks und Erfüllungsquote"],
  },
  {
    path: "/app/hobbys", label: "Hobbys", icon: Palette,
    summary: "Was dir Freude macht.",
    planned: ["Hobbys mit Notizen und Fortschritt"],
  },
  {
    path: "/app/social-media", label: "Social Media", icon: Smartphone, showOnLanding: true,
    summary: "Bildschirmzeit und die Zahlen deiner eigenen Accounts.",
    planned: [
      "Bildschirmzeit pro Plattform, Wochen- und Monatsvergleich",
      "Eigene Accounts mit Follower- bzw. Abo-Entwicklung",
      "Jeder Post mit Datum, Uhrzeit, Thema, Inhalt, Format und Videolänge",
      "Likes, Kommentare, Shares, Saves, Views und neue Follower pro Post",
      "Auswertung: beste Wochentage und Uhrzeiten zum Posten",
      "Auswertung: welche Themen, Formate und Videolängen am besten ankommen",
    ],
  },
  {
    path: "/app/wetter", label: "Wetter", icon: CloudSun, showOnLanding: true,
    summary: "Das Wetter an deinem Wohnort.",
    planned: ["Temperatur, Regen, Wind, Luftfeuchtigkeit", "Prognose für die nächsten Tage"],
  },
  {
    path: "/app/entwicklung", label: "Meine Entwicklung", icon: LineChart, showOnLanding: true,
    summary: "Alle Bereiche zusammengeführt – mit Hinweisen aus deinen echten Daten.",
    planned: ["Übersicht über alle Lebensbereiche", "Neutrale Hinweise, nur aus deinen eingetragenen Daten", "Zeiträume: 7 Tage bis 1 Jahr"],
  },
  { path: "/app/einstellungen", label: "Einstellungen", icon: Settings, summary: "Konto, Daten und Datenschutz." },
];

