import { useLocation } from "react-router";
import { Check } from "lucide-react";
import { Card } from "../components/ui";
import { MODULES } from "../lib/modules";

// Zeigt für noch nicht gebaute Module, was dort geplant ist.
export default function ModulePlaceholder() {
  const { pathname } = useLocation();
  const mod = MODULES.find((m) => m.path === pathname);
  if (!mod) return <h1 className="text-3xl font-bold">Diese Seite gibt es nicht.</h1>;
  const Icon = mod.icon;

  return (
    <div>
      <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-sun"><Icon size={24} aria-hidden="true" /></span>
      <h1 className="mt-4 text-4xl font-extrabold">{mod.label}</h1>
      <p className="mt-2 max-w-xl text-lg text-ink-soft">{mod.summary}</p>
      <Card className="mt-8">
        <h2 className="text-xl font-bold">In Arbeit</h2>
        <p className="mt-1 text-ink-soft">Dieser Bereich wird im nächsten Schritt gebaut. Geplant sind:</p>
        <ul className="mt-4 space-y-2.5">
          {mod.planned?.map((item) => (
            <li key={item} className="flex gap-3">
              <Check size={18} className="mt-0.5 shrink-0 text-good" aria-hidden="true" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
