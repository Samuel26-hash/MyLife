import { useState, type FormEvent, type ReactNode } from "react";
import { Link, Navigate, useNavigate } from "react-router";
import { Alert, Button, Field, Input, Logo } from "../components/ui";
import { useAuth } from "../lib/auth";

function AuthShell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="grid min-h-screen md:grid-cols-2">
      <aside className="hidden flex-col justify-between bg-sun p-10 md:flex">
        <Link to="/"><Logo /></Link>
        <p className="font-display text-5xl font-extrabold leading-[0.95]">
          Dein Leben.<br />Deine Ziele.<br />Deine Entwicklung.
        </p>
        <span className="text-sm text-ink/70">Created by Lenny Luvuezo</span>
      </aside>
      <main className="flex items-center justify-center bg-paper px-5 py-12">
        <div className="w-full max-w-sm">
          <Link to="/" className="md:hidden"><Logo /></Link>
          <h1 className="mt-8 text-3xl font-bold md:mt-0">{title}</h1>
          {children}
        </div>
      </main>
    </div>
  );
}

export function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/app" replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      await login(email, password);
      navigate("/app");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Anmeldung fehlgeschlagen.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell title="Anmelden">
      <form onSubmit={submit} className="mt-6 space-y-4">
        {err && <Alert>{err}</Alert>}
        <Field label="E-Mail">
          <Input type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </Field>
        <Field label="Passwort">
          <Input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </Field>
        <Button type="submit" variant="dark" className="w-full py-3" disabled={busy}>
          {busy ? "Wird angemeldet …" : "Anmelden"}
        </Button>
        <p className="text-center text-sm text-ink-soft">
          Passwort vergessen? Diese Funktion kommt, sobald der E-Mail-Versand eingerichtet ist.
        </p>
      </form>
      <p className="mt-8 text-sm">
        Noch kein Konto? <Link to="/registrieren" className="font-semibold underline underline-offset-4">Kostenlos registrieren</Link>
      </p>
    </AuthShell>
  );
}

export function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [firstName, setFirstName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/app" replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setErr("");
    if (password.length < 10) return setErr("Das Passwort muss mindestens 10 Zeichen lang sein.");
    setBusy(true);
    try {
      await register(firstName, email, password);
      navigate("/app/einrichten");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Registrierung fehlgeschlagen.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell title="Konto erstellen">
      <form onSubmit={submit} className="mt-6 space-y-4">
        {err && <Alert>{err}</Alert>}
        <Field label="Vorname">
          <Input autoComplete="given-name" required maxLength={60} value={firstName} onChange={(e) => setFirstName(e.target.value)} />
        </Field>
        <Field label="E-Mail">
          <Input type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </Field>
        <Field label="Passwort" hint="Mindestens 10 Zeichen.">
          <Input type="password" autoComplete="new-password" required minLength={10} value={password} onChange={(e) => setPassword(e.target.value)} />
        </Field>
        <Button type="submit" variant="dark" className="w-full py-3" disabled={busy}>
          {busy ? "Konto wird erstellt …" : "Konto erstellen"}
        </Button>
      </form>
      <p className="mt-8 text-sm">
        Schon registriert? <Link to="/anmelden" className="font-semibold underline underline-offset-4">Anmelden</Link>
      </p>
    </AuthShell>
  );
}
