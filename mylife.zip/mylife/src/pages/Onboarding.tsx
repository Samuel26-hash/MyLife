import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { Alert, Button, Card } from "../components/ui";
import { ProfileFields } from "../components/ProfileForm";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { PROFILE_GROUPS, type Profile, type ProfileField } from "../lib/profile";

export default function Onboarding() {
  const { refresh } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [values, setValues] = useState<Partial<Profile>>({});
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api<{ profile: Profile }>("/api/profile").then((d) => setValues(d.profile ?? {})).catch(() => {});
  }, []);

  const group = PROFILE_GROUPS[step];
  const last = step === PROFILE_GROUPS.length - 1;

  const save = async (finish: boolean) => {
    setErr("");
    setBusy(true);
    try {
      const body: Record<string, unknown> = {};
      for (const f of group.fields) body[f.key] = values[f.key] ?? null;
      if (finish) body.onboarding_done = true;
      await api("/api/profile", { method: "PUT", body });
      if (finish) {
        await refresh();
        navigate("/app");
      } else {
        setStep(step + 1);
      }
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Speichern fehlgeschlagen.");
    } finally {
      setBusy(false);
    }
  };

  const change = (key: ProfileField, value: string) => setValues((v) => ({ ...v, [key]: value }));

  return (
    <div className="mx-auto max-w-2xl">
      <p className="text-ink-soft">Schritt {step + 1} von {PROFILE_GROUPS.length}</p>
      <div className="mt-2 flex gap-1.5" aria-hidden="true">
        {PROFILE_GROUPS.map((g, i) => (
          <span key={g.title} className={`h-1.5 flex-1 rounded-full ${i <= step ? "bg-ink" : "bg-line"}`} />
        ))}
      </div>
      <h1 className="mt-6 text-4xl font-extrabold">{group.title}</h1>
      <p className="mt-2 text-ink-soft">Alles ist freiwillig. Du kannst es später jederzeit im Profil ändern oder löschen.</p>

      <Card className="mt-6">
        {err && <div className="mb-4"><Alert>{err}</Alert></div>}
        <ProfileFields fields={group.fields} values={values} onChange={change} />
      </Card>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <Button variant="ghost" onClick={() => (step === 0 ? save(true) : setStep(step - 1))} disabled={busy}>
          {step === 0 ? "Überspringen" : "Zurück"}
        </Button>
        <Button variant="dark" onClick={() => save(last)} disabled={busy}>
          {busy ? "Wird gespeichert …" : last ? "Fertig" : "Weiter"}
        </Button>
      </div>
    </div>
  );
}
