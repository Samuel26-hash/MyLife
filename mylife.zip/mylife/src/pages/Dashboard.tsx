import { Link } from "react-router";
import { ArrowUpRight } from "lucide-react";
import { Card, ButtonLink } from "../components/ui";
import { useAuth } from "../lib/auth";
import { MODULES } from "../lib/modules";

function greeting(): string {
  const h = new Date().getHours();
  if (h < 11) return "Guten Morgen";
  if (h < 18) return "Hallo";
  return "Guten Abend";
}

// Kacheln für "Heute". Solange ein Modul noch keine Daten hat, zeigt die Kachel,
// was man als Nächstes tun kann – es werden nie erfundene Zahlen angezeigt.
const TODAY = [
  { path: "/app/wetter", empty: "Trag deinen Wohnort im Profil ein, dann siehst du hier das Wetter." },
  { path: "/app/kalender", empty: "Heute stehen keine Termine an." },
  { path: "/app/ziele", empty: "Du hast noch keine Ziele. Setz dir dein erstes." },
  { path: "/app/gewohnheiten", empty: "Wähle Gewohnheiten aus, die du täglich abhaken willst." },
  { path: "/app/sport", empty: "Heute noch kein Training eingetragen." },
  { path: "/app/ernaehrung", empty: "Heute noch keine Mahlzeit eingetragen." },
];

const PROGRESS = ["/app/schule", "/app/sport", "/app/ernaehrung", "/app/gewohnheiten", "/app/finanzen", "/app/ziele"];

export default function Dashboard() {
  const { user } = useAuth();
  const today = new Intl.DateTimeFormat("de-CH", { weekday: "long", day: "numeric", month: "long" }).format(new Date());
  const byPath = (p: string) => MODULES.find((m) => m.path === p)!;

  return (
    <div>
      <p className="text-ink-soft">{today}</p>
      <h1 className="mt-1 text-4xl font-extrabold sm:text-5xl">
        {greeting()}{user?.first_name ? `, ${user.first_name}` : ""}.
      </h1>

      {!user?.onboarding_done && (
        <div className="mt-6 flex flex-col gap-4 rounded-[var(--radius-card)] bg-sun p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
          <div>
            <h2 className="text-xl font-bold">Richte dein Profil ein</h2>
            <p className="text-ink/75">Drei kurze Schritte, damit MyLife zu dir passt. Alle Angaben sind freiwillig.</p>
          </div>
          <ButtonLink to="/app/einrichten" variant="dark">Jetzt einrichten</ButtonLink>
        </div>
      )}

      <h2 className="mt-10 text-2xl font-bold">Heute</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {TODAY.map(({ path, empty }) => {
          const { label, icon: Icon } = byPath(path);
          return (
            <Link key={path} to={path} className="group rounded-[var(--radius-card)] bg-paper p-5 transition-colors hover:bg-honey">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 font-semibold"><Icon size={18} aria-hidden="true" /> {label}</span>
                <ArrowUpRight size={18} className="text-ink-soft group-hover:text-ink" aria-hidden="true" />
              </div>
              <p className="mt-3 text-sm text-ink-soft">{empty}</p>
            </Link>
          );
        })}
      </div>

      <h2 className="mt-10 text-2xl font-bold">Fortschritt</h2>
      <Card className="mt-4">
        <ul className="divide-y divide-line">
          {PROGRESS.map((path) => {
            const { label, icon: Icon } = byPath(path);
            return (
              <li key={path} className="flex items-center gap-4 py-3.5 first:pt-0 last:pb-0">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-honey"><Icon size={18} aria-hidden="true" /></span>
                <span className="flex-1 font-medium">{label}</span>
                <span className="text-sm text-ink-soft">Noch keine Daten</span>
              </li>
            );
          })}
        </ul>
        <p className="mt-5 text-sm text-ink-soft">
          Sobald du Einträge machst, erscheinen hier Fortschrittsbalken und Diagramme. MyLife zeigt nur, was du selbst eingetragen hast.
        </p>
      </Card>
    </div>
  );
}
