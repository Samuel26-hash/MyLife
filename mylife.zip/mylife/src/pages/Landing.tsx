import { Lock, Download, Trash2, EyeOff } from "lucide-react";
import { ButtonLink, Logo } from "../components/ui";
import { LifeWheel } from "../components/LifeWheel";
import { MODULES } from "../lib/modules";

export default function Landing() {
  const features = MODULES.filter((m) => m.showOnLanding);

  return (
    <div className="min-h-screen bg-paper">
      {/* Hero: vollflächig gelb */}
      <header className="bg-sun">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
          <Logo />
          <ButtonLink to="/anmelden" variant="ghost" className="border-ink/20 bg-white/40">Anmelden</ButtonLink>
        </div>
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 pb-16 pt-6 sm:px-8 md:grid-cols-[1.1fr_1fr] md:pb-24 md:pt-12">
          <div>
            <h1 className="text-[clamp(2.6rem,7vw,5.2rem)] font-extrabold leading-[0.95]">
              Dein Leben.
              <br />
              Deine Ziele.
              <br />
              Deine Entwicklung.
            </h1>
            <p className="mt-6 max-w-[34rem] text-lg leading-relaxed text-ink/80">
              MyLife hilft dir dabei, wichtige Bereiche deines Lebens an einem Ort zu organisieren, deine Entwicklung zu
              verfolgen und herauszufinden, wo du dich verbessern kannst.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <ButtonLink to="/registrieren" variant="dark" className="px-7 py-3.5 text-base">Kostenlos starten</ButtonLink>
              <ButtonLink to="/anmelden" variant="ghost" className="border-ink/25 px-7 py-3.5 text-base">Anmelden</ButtonLink>
            </div>
          </div>
          <figure className="flex flex-col items-center">
            <LifeWheel />
            <figcaption className="mt-1 text-sm text-ink/70">Beispielansicht mit Demo-Werten</figcaption>
          </figure>
        </div>
      </header>

      {/* Funktionen */}
      <main>
        <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8 md:py-24">
          <h2 className="max-w-xl text-3xl font-bold sm:text-4xl">Alles, was dir wichtig ist, an einem Ort.</h2>
          <ul className="mt-10 grid gap-x-10 gap-y-7 sm:grid-cols-2 lg:grid-cols-3">
            {features.map(({ label, summary, icon: Icon }) => (
              <li key={label} className="flex gap-4">
                <span className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-honey">
                  <Icon size={20} strokeWidth={2} aria-hidden="true" />
                </span>
                <div>
                  <h3 className="text-lg font-bold">{label}</h3>
                  <p className="mt-0.5 text-ink-soft">{summary}</p>
                </div>
              </li>
            ))}
          </ul>
        </section>

        {/* Datenschutz */}
        <section className="bg-ink text-white">
          <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 sm:px-8 md:grid-cols-[1fr_1.4fr] md:py-20">
            <div>
              <h2 className="text-3xl font-bold sm:text-4xl">Deine Daten gehören dir.</h2>
              <p className="mt-4 max-w-md text-white/70">
                MyLife speichert persönliche Dinge wie Noten oder Finanzen. Deshalb ist Sicherheit von Anfang an eingebaut.
              </p>
            </div>
            <ul className="grid gap-6 sm:grid-cols-2">
              {[
                { icon: EyeOff, title: "Nur für dich sichtbar", text: "Niemand sonst sieht deine Einträge." },
                { icon: Lock, title: "Sicher gespeichert", text: "Passwörter werden nur verschlüsselt gespeichert." },
                { icon: Download, title: "Jederzeit exportieren", text: "Lade alle deine Daten als Datei herunter." },
                { icon: Trash2, title: "Jederzeit löschen", text: "Dein Konto und alle Daten lassen sich vollständig löschen." },
              ].map(({ icon: Icon, title, text }) => (
                <li key={title}>
                  <Icon size={22} className="text-sun" aria-hidden="true" />
                  <h3 className="mt-2 font-bold">{title}</h3>
                  <p className="mt-1 text-sm text-white/70">{text}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 py-16 text-center sm:px-8">
          <h2 className="text-3xl font-bold">Bereit für deinen Überblick?</h2>
          <ButtonLink to="/registrieren" className="mt-6 px-7 py-3.5 text-base">Kostenlos starten</ButtonLink>
        </section>
      </main>

      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-6 text-sm text-ink-soft sm:px-8" style={{ paddingBottom: "calc(1.5rem + env(safe-area-inset-bottom, 0px))" }}>
          <Logo className="text-base text-ink" />
          <span>Created by Lenny Luvuezo</span>
        </div>
      </footer>
    </div>
  );
}
