import { useState } from "react";
import { useNavigate } from "react-router";
import { Download, LogOut, Trash2 } from "lucide-react";
import { Alert, Button, Card, Field, Input } from "../components/ui";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";

export default function Settings() {
  const { user, logout, refresh } = useAuth();
  const navigate = useNavigate();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const exportData = async () => {
    setErr("");
    try {
      const data = await api("/api/account/export");
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `mylife-export-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Export fehlgeschlagen.");
    }
  };

  const deleteAccount = async () => {
    setErr("");
    setBusy(true);
    try {
      await api("/api/account/delete", { method: "POST", body: { password } });
      await refresh();
      navigate("/");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Löschen fehlgeschlagen.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <h1 className="text-4xl font-extrabold">Einstellungen</h1>
      <p className="mt-2 text-ink-soft">Angemeldet als {user?.email}</p>
      {err && <div className="mt-6"><Alert>{err}</Alert></div>}

      <div className="mt-8 space-y-4">
        <Card>
          <h2 className="text-xl font-bold">Deine Daten</h2>
          <p className="mt-1 text-ink-soft">Lade alle Daten, die MyLife über dich gespeichert hat, als JSON-Datei herunter.</p>
          <Button variant="ghost" className="mt-4" onClick={exportData}><Download size={16} aria-hidden="true" /> Daten exportieren</Button>
        </Card>

        <Card>
          <h2 className="text-xl font-bold">Abmelden</h2>
          <p className="mt-1 text-ink-soft">Beendet die Sitzung auf diesem Gerät.</p>
          <Button variant="ghost" className="mt-4" onClick={async () => { await logout(); navigate("/"); }}>
            <LogOut size={16} aria-hidden="true" /> Abmelden
          </Button>
        </Card>

        <Card className="border border-bad/30">
          <h2 className="text-xl font-bold text-bad">Konto löschen</h2>
          <p className="mt-1 text-ink-soft">Löscht dein Konto und alle Einträge endgültig. Das lässt sich nicht rückgängig machen.</p>
          {!confirmDelete ? (
            <Button variant="ghost" className="mt-4 border-bad/40 text-bad" onClick={() => setConfirmDelete(true)}>
              <Trash2 size={16} aria-hidden="true" /> Konto löschen …
            </Button>
          ) : (
            <div className="mt-4 max-w-sm space-y-3">
              <Field label="Zur Bestätigung dein Passwort">
                <Input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </Field>
              <div className="flex gap-3">
                <Button variant="ghost" onClick={() => { setConfirmDelete(false); setPassword(""); }}>Abbrechen</Button>
                <Button variant="danger" onClick={deleteAccount} disabled={busy || !password}>
                  {busy ? "Wird gelöscht …" : "Konto endgültig löschen"}
                </Button>
              </div>
            </div>
          )}
        </Card>
      </div>
      <p className="mt-10 text-sm text-ink-soft">MyLife – Created by Lenny Luvuezo</p>
    </div>
  );
}
