import { useEffect, useState } from "react";
import { Pencil } from "lucide-react";
import { Alert, Button, Card } from "../components/ui";
import { ProfileFields } from "../components/ProfileForm";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { PROFILE_GROUPS, ageFrom, type Profile as ProfileT, type ProfileField } from "../lib/profile";

export default function Profile() {
  const { refresh } = useAuth();
  const [profile, setProfile] = useState<ProfileT | null>(null);
  const [draft, setDraft] = useState<Partial<ProfileT>>({});
  const [editing, setEditing] = useState(false);
  const [msg, setMsg] = useState<{ tone: "good" | "bad"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api<{ profile: ProfileT }>("/api/profile")
      .then((d) => setProfile(d.profile))
      .catch((e) => setMsg({ tone: "bad", text: e.message }));
  }, []);

  const startEdit = () => {
    setDraft(profile ?? {});
    setEditing(true);
    setMsg(null);
  };

  const save = async () => {
    setBusy(true);
    setMsg(null);
    try {
      const body: Record<string, unknown> = {};
      for (const g of PROFILE_GROUPS) for (const f of g.fields) body[f.key] = draft[f.key] ?? null;
      const d = await api<{ profile: ProfileT }>("/api/profile", { method: "PUT", body });
      setProfile(d.profile);
      setEditing(false);
      setMsg({ tone: "good", text: "Profil gespeichert." });
      await refresh();
    } catch (e) {
      setMsg({ tone: "bad", text: e instanceof Error ? e.message : "Speichern fehlgeschlagen." });
    } finally {
      setBusy(false);
    }
  };

  if (!profile) return msg ? <Alert>{msg.text}</Alert> : <p className="text-ink-soft">Profil wird geladen …</p>;

  const name = [profile.first_name, profile.last_name].filter(Boolean).join(" ") || "Dein Name";
  const age = ageFrom(profile.birthday);
  const initials = name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="flex items-center gap-5">
          <span className="flex h-20 w-20 items-center justify-center rounded-full bg-sun font-display text-2xl font-extrabold">{initials}</span>
          <div>
            <h1 className="text-4xl font-extrabold">{name}</h1>
            <p className="text-ink-soft">
              {[age !== null ? `${age} Jahre` : null, profile.city, profile.nationality].filter(Boolean).join(", ") || "Noch keine Angaben"}
            </p>
          </div>
        </div>
        {!editing && <Button variant="ghost" onClick={startEdit}><Pencil size={16} aria-hidden="true" /> Profil bearbeiten</Button>}
      </div>

      {msg && <div className="mt-6"><Alert tone={msg.tone}>{msg.text}</Alert></div>}

      {editing ? (
        <div className="mt-8 space-y-6">
          {PROFILE_GROUPS.map((g) => (
            <Card key={g.title}>
              <h2 className="mb-4 text-xl font-bold">{g.title}</h2>
              <ProfileFields fields={g.fields} values={draft} onChange={(k: ProfileField, v) => setDraft((d) => ({ ...d, [k]: v }))} />
            </Card>
          ))}
          <div className="flex justify-end gap-3">
            <Button variant="ghost" onClick={() => setEditing(false)} disabled={busy}>Abbrechen</Button>
            <Button variant="dark" onClick={save} disabled={busy}>{busy ? "Wird gespeichert …" : "Änderungen speichern"}</Button>
          </div>
        </div>
      ) : (
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {PROFILE_GROUPS.map((g) => (
            <Card key={g.title} className={g.title === "Ziele" ? "md:col-span-2" : ""}>
              <h2 className="text-xl font-bold">{g.title}</h2>
              <dl className="mt-3 divide-y divide-line">
                {g.fields.map((f) => (
                  <div key={f.key} className="grid grid-cols-[minmax(0,10rem)_1fr] gap-3 py-2.5">
                    <dt className="text-sm text-ink-soft">{f.label}</dt>
                    <dd className="whitespace-pre-line">
                      {f.key === "birthday" && profile.birthday
                        ? new Intl.DateTimeFormat("de-CH", { dateStyle: "long" }).format(new Date(profile.birthday))
                        : profile[f.key] || <span className="text-ink-soft/60">–</span>}
                    </dd>
                  </div>
                ))}
              </dl>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
